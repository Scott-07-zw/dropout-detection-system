'use client';
import React, { useState } from 'react';
import { toast } from 'sonner';
import { Save, Users, CheckSquare, Square, ChevronDown, Calendar, BookOpen } from 'lucide-react';
import { mockStudents, mockModules, mockAttendance, mockGrades, computeRisk } from '@/lib/mockData';
import RiskBadge from '@/components/ui/RiskBadge';

// BACKEND INTEGRATION POINT: POST /api/attendance/save { moduleId, sessionDate, records: [{studentId, present}] }

const SESSION_DATE = '30/08/2026';

export default function AttendanceClient() {
  const [selectedModuleId, setSelectedModuleId] = useState('mod-001');
  const [isSaving, setIsSaving] = useState(false);

  const module = mockModules.find((m) => m.id === selectedModuleId)!;
  const enrolledStudents = mockStudents.filter((s) =>
    mockGrades.some((g) => g.moduleId === selectedModuleId && g.studentId === s.id)
  );

  // Build initial attendance state from mock records for today's session
  const initialAttendance: Record<string, boolean> = {};
  enrolledStudents.forEach((s) => {
    // Default to present for new session
    initialAttendance[s.id] = true;
  });

  const [attendance, setAttendance] = useState<Record<string, boolean>>(initialAttendance);

  const presentCount = Object.values(attendance).filter(Boolean).length;
  const totalCount = enrolledStudents.length;
  const attendanceRate = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

  const toggleStudent = (studentId: string) => {
    setAttendance((prev) => ({ ...prev, [studentId]: !prev[studentId] }));
  };

  const markAll = (present: boolean) => {
    const next: Record<string, boolean> = {};
    enrolledStudents.forEach((s) => { next[s.id] = present; });
    setAttendance(next);
  };

  const handleSave = async () => {
    setIsSaving(true);
    // BACKEND INTEGRATION POINT: POST /api/attendance/save
    await new Promise((r) => setTimeout(r, 1400));
    setIsSaving(false);
    toast.success(`Attendance saved — Session 13, ${module.code}, ${SESSION_DATE}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-700 text-foreground">Mark Attendance</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Session 13 — {SESSION_DATE}</p>
        </div>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-60 disabled:cursor-not-allowed self-start sm:self-auto"
        >
          {isSaving ? (
            <>
              <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
              </svg>
              Saving…
            </>
          ) : (
            <>
              <Save size={16} />
              Save Attendance
            </>
          )}
        </button>
      </div>

      {/* Module selector + session info */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="sm:col-span-2 bg-card border border-border rounded-xl p-4">
          <label className="block text-xs font-600 text-muted-foreground uppercase tracking-wider mb-2">
            <BookOpen size={12} className="inline mr-1" />
            Select Module
          </label>
          <div className="relative">
            <select
              value={selectedModuleId}
              onChange={(e) => setSelectedModuleId(e.target.value)}
              className="w-full appearance-none bg-input border border-border rounded-lg px-3 py-2.5 text-sm font-500 text-foreground focus:outline-none focus:ring-2 focus:ring-ring pr-8"
            >
              {mockModules.map((m) => (
                <option key={`mod-opt-${m.id}`} value={m.id}>
                  {m.code} — {m.name}
                </option>
              ))}
            </select>
            <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-xs font-600 text-muted-foreground uppercase tracking-wider mb-1">
            <Calendar size={12} className="inline mr-1" />
            Session Date
          </p>
          <p className="text-base font-700 text-foreground">{SESSION_DATE}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Session 13 of 15</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-xs font-600 text-muted-foreground uppercase tracking-wider mb-1">
            <Users size={12} className="inline mr-1" />
            Present Today
          </p>
          <p className="text-base font-700 text-foreground tabular-nums">{presentCount} / {totalCount}</p>
          <div className="flex items-center gap-2 mt-1.5">
            <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${attendanceRate}%`, backgroundColor: attendanceRate < 50 ? 'var(--risk-red)' : attendanceRate < 75 ? 'var(--risk-amber)' : 'var(--risk-green)' }}
              />
            </div>
            <span className={`text-xs font-700 tabular-nums ${attendanceRate < 50 ? 'text-risk-red' : attendanceRate < 75 ? 'text-risk-amber' : 'text-risk-green'}`}>
              {attendanceRate}%
            </span>
          </div>
        </div>
      </div>

      {/* Bulk actions */}
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-sm font-500 text-muted-foreground">Bulk actions:</span>
        <button
          onClick={() => markAll(true)}
          className="flex items-center gap-1.5 text-sm font-500 text-risk-green bg-risk-green-bg border border-risk-green-border px-3 py-1.5 rounded-lg hover:bg-green-100 transition-colors"
        >
          <CheckSquare size={14} />
          Mark All Present
        </button>
        <button
          onClick={() => markAll(false)}
          className="flex items-center gap-1.5 text-sm font-500 text-risk-red bg-risk-red-bg border border-risk-red-border px-3 py-1.5 rounded-lg hover:bg-red-100 transition-colors"
        >
          <Square size={14} />
          Mark All Absent
        </button>
      </div>

      {/* Attendance table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border bg-muted/30 flex items-center justify-between">
          <h2 className="text-sm font-600 text-foreground">
            {module.code} — {module.name} — Enrolled Students
          </h2>
          <span className="text-xs text-muted-foreground">{totalCount} students</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {['Reg Number', 'Full Name', 'Programme', 'Year', 'Registered', 'Consec. Absences', 'Risk Level', 'Present Today'].map((h) => (
                  <th key={`att-th-${h}`} className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {enrolledStudents.map((stu) => {
                const grade = mockGrades.find((g) => g.studentId === stu.id);
                const stuAttendance = mockAttendance.filter((a) => a.studentId === stu.id && a.moduleId === selectedModuleId);
                const risk = computeRisk(stu, grade, stuAttendance);
                const isPresent = attendance[stu.id];

                return (
                  <tr
                    key={`att-row-${stu.id}`}
                    className={[
                      'border-b border-border last:border-0 transition-colors hover:bg-muted/20',
                      !isPresent ? 'opacity-75' : '',
                    ].join(' ')}
                  >
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground whitespace-nowrap">{stu.regNumber}</td>
                    <td className="px-4 py-3">
                      <p className="font-600 text-foreground text-sm">{stu.firstName} {stu.lastName}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{stu.programme}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground text-center">Year {stu.year}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-600 ${stu.isRegistered ? 'risk-green-badge' : 'risk-red-badge'}`}>
                        {stu.isRegistered ? '✓ Reg' : '✗ Unreg'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`tabular-nums font-700 text-sm ${risk.consecutiveAbsences >= 10 ? 'text-risk-red' : risk.consecutiveAbsences >= 5 ? 'text-risk-amber' : 'text-foreground'}`}>
                        {risk.consecutiveAbsences}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <RiskBadge level={risk.riskLevel} size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleStudent(stu.id)}
                        className={[
                          'relative inline-flex items-center w-12 h-6 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1',
                          isPresent ? 'bg-risk-green' : 'bg-muted-foreground/30',
                        ].join(' ')}
                        role="switch"
                        aria-checked={isPresent}
                        aria-label={`Mark ${stu.firstName} ${isPresent ? 'absent' : 'present'}`}
                      >
                        <span
                          className={[
                            'inline-block w-4 h-4 bg-white rounded-full shadow transition-transform duration-200',
                            isPresent ? 'translate-x-7' : 'translate-x-1',
                          ].join(' ')}
                        />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Session history */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border">
          <h2 className="text-base font-600 text-foreground">Recent Session History — {module.code}</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Last 5 sessions recorded</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {['Session', 'Date', 'Present', 'Absent', 'Rate', 'Recorded By'].map((h) => (
                  <th key={`hist-th-${h}`} className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wider">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { session: 12, date: '28/08/2026', present: 6, absent: 2, rate: 75, by: 'Dr. T. Muzorewa' },
                { session: 11, date: '26/08/2026', present: 7, absent: 1, rate: 88, by: 'Dr. T. Muzorewa' },
                { session: 10, date: '24/08/2026', present: 5, absent: 3, rate: 63, by: 'Dr. T. Muzorewa' },
                { session: 9, date: '21/08/2026', present: 7, absent: 1, rate: 88, by: 'Dr. T. Muzorewa' },
                { session: 8, date: '19/08/2026', present: 8, absent: 0, rate: 100, by: 'Dr. T. Muzorewa' },
              ].map((row) => (
                <tr key={`hist-row-${row.session}`} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 font-600 text-foreground tabular-nums">Session {row.session}</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">{row.date}</td>
                  <td className="px-4 py-3 text-risk-green font-600 tabular-nums">{row.present}</td>
                  <td className="px-4 py-3 text-risk-red font-600 tabular-nums">{row.absent}</td>
                  <td className="px-4 py-3">
                    <span className={`tabular-nums font-700 text-sm ${row.rate < 50 ? 'text-risk-red' : row.rate < 75 ? 'text-risk-amber' : 'text-risk-green'}`}>
                      {row.rate}%
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{row.by}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}