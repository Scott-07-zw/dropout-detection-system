import AppLayout from '@/components/AppLayout';
import AttendanceClient from './components/AttendanceClient';

export default function AttendanceScreenPage() {
  return (
    <AppLayout userRole="lecturer" userName="Dr. Tendai Muzorewa">
      <AttendanceClient />
    </AppLayout>
  );
}