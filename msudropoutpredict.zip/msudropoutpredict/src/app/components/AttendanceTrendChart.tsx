'use client';
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { weeklyAttendanceTrend } from '@/lib/mockData';

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg shadow-lg px-3 py-2">
      <p className="text-xs font-600 text-foreground mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={`tp-${i}`} className="text-xs text-muted-foreground">
          <span className="font-500 text-foreground">{p.value}{p.name === 'rate' ? '%' : ' students'}</span>{' '}
          {p.name === 'rate' ? 'attended' : 'absent'}
        </p>
      ))}
    </div>
  );
};

export default function AttendanceTrendChart() {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={weeklyAttendanceTrend} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="attendanceGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.2} />
            <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="week" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} domain={[50, 100]} />
        <Tooltip content={<CustomTooltip />} />
        <Area type="monotone" dataKey="rate" stroke="var(--primary)" strokeWidth={2} fill="url(#attendanceGrad)" name="rate" />
      </AreaChart>
    </ResponsiveContainer>
  );
}