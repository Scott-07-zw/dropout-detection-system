'use client';
import React from 'react';
import dynamic from 'next/dynamic';

const AttendanceTrendChart = dynamic(() => import('./AttendanceTrendChart'), { ssr: false });
const RiskDistributionChart = dynamic(() => import('./RiskDistributionChart'), { ssr: false });
const ModuleAvgMarksChart = dynamic(() => import('./ModuleAvgMarksChart'), { ssr: false });

export default function DashboardChartsRow() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-6">
      <div className="lg:col-span-2 bg-card border border-border rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-600 text-foreground">Weekly Attendance Trend</h2>
            <p className="text-xs text-muted-foreground mt-0.5">CS201 — Semester 1, 2026</p>
          </div>
          <span className="text-xs font-500 text-risk-red bg-red-50 border border-risk-red-border px-2 py-1 rounded-full">
            ↓ Declining
          </span>
        </div>
        <AttendanceTrendChart />
      </div>
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="mb-4">
          <h2 className="text-base font-600 text-foreground">Risk Distribution</h2>
          <p className="text-xs text-muted-foreground mt-0.5">All monitored students</p>
        </div>
        <RiskDistributionChart />
      </div>
    </div>
  );
}