import React from 'react';
import { AlertTriangle, Users, CheckCircle, BookOpen, TrendingDown, Activity } from 'lucide-react';

// BACKEND INTEGRATION POINT: Fetch from GET /api/dashboard/kpis
const kpis = [
  {
    id: 'kpi-red-students',
    label: 'High Risk Students',
    value: '3',
    sub: 'Require immediate attention',
    icon: <AlertTriangle size={20} />,
    trend: '+1 since last week',
    trendUp: false,
    colorClass: 'border-l-4 border-risk-red bg-red-50',
    iconBg: 'bg-red-100',
    iconColor: 'text-risk-red',
    trendColor: 'text-risk-red',
  },
  {
    id: 'kpi-amber-students',
    label: 'Moderate Risk Students',
    value: '4',
    sub: 'Monitoring required',
    icon: <Activity size={20} />,
    trend: 'No change',
    trendUp: null,
    colorClass: 'border-l-4 border-risk-amber bg-amber-50',
    iconBg: 'bg-amber-100',
    iconColor: 'text-risk-amber',
    trendColor: 'text-muted-foreground',
  },
  {
    id: 'kpi-green-students',
    label: 'No Risk Students',
    value: '5',
    sub: 'Meeting all requirements',
    icon: <CheckCircle size={20} />,
    trend: '-1 since last week',
    trendUp: false,
    colorClass: 'border-l-4 border-risk-green bg-green-50',
    iconBg: 'bg-green-100',
    iconColor: 'text-risk-green',
    trendColor: 'text-risk-amber',
  },
  {
    id: 'kpi-attendance',
    label: 'Avg Attendance Rate',
    value: '68%',
    sub: 'Down from 85% in Week 4',
    icon: <Users size={20} />,
    trend: '↓ 17pp over 4 weeks',
    trendUp: false,
    colorClass: 'bg-card border border-border',
    iconBg: 'bg-secondary',
    iconColor: 'text-primary',
    trendColor: 'text-risk-red',
  },
  {
    id: 'kpi-registered',
    label: 'Registered Students',
    value: '9 / 12',
    sub: '3 unregistered — flagged red',
    icon: <BookOpen size={20} />,
    trend: '75% registration rate',
    trendUp: null,
    colorClass: 'bg-card border border-border',
    iconBg: 'bg-secondary',
    iconColor: 'text-primary',
    trendColor: 'text-muted-foreground',
  },
  {
    id: 'kpi-avg-mark',
    label: 'Avg Academic Mark',
    value: '48%',
    sub: 'CS201 cohort average',
    icon: <TrendingDown size={20} />,
    trend: 'Below 50% threshold',
    trendUp: false,
    colorClass: 'bg-card border border-border',
    iconBg: 'bg-secondary',
    iconColor: 'text-primary',
    trendColor: 'text-risk-amber',
  },
];

export default function DashboardKPIGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-6 gap-4">
      {kpis?.map((kpi) => (
        <div
          key={kpi?.id}
          className={`rounded-xl p-5 ${kpi?.colorClass} transition-shadow hover:shadow-md`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className={`p-2 rounded-lg ${kpi?.iconBg} flex-shrink-0`}>
              <span className={kpi?.iconColor}>{kpi?.icon}</span>
            </div>
          </div>
          <div className="mt-3">
            <p className="text-xs font-600 text-muted-foreground uppercase tracking-wider">{kpi?.label}</p>
            <p className="text-3xl font-700 text-foreground tabular-nums mt-1">{kpi?.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{kpi?.sub}</p>
            <p className={`text-xs font-500 mt-2 ${kpi?.trendColor}`}>{kpi?.trend}</p>
          </div>
        </div>
      ))}
    </div>
  );
}