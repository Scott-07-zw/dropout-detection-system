import React from 'react';
import { AlertTriangle, UserX, TrendingDown, Clock } from 'lucide-react';

// BACKEND INTEGRATION POINT: Fetch from GET /api/alerts/recent?limit=5
const alerts = [
  { id: 'alert-001', icon: <UserX size={14} />, iconBg: 'bg-red-100', iconColor: 'text-risk-red', title: 'Unregistered student', desc: 'Nyasha Dzingai (R214012L) is not registered for Semester 1.', time: '2h ago' },
  { id: 'alert-002', icon: <AlertTriangle size={14} />, iconBg: 'bg-red-100', iconColor: 'text-risk-red', title: '11 consecutive absences', desc: 'Blessing Zvobgo (R214678R) has not attended CS201 in 11 sessions.', time: '4h ago' },
  { id: 'alert-003', icon: <TrendingDown size={14} />, iconBg: 'bg-amber-100', iconColor: 'text-risk-amber', title: 'Coursework below threshold', desc: 'Simbai Chikwanda (R213789K) scored 10/20 on coursework.', time: '1d ago' },
  { id: 'alert-004', icon: <UserX size={14} />, iconBg: 'bg-red-100', iconColor: 'text-risk-red', title: 'Unregistered student', desc: 'Kudakwashe Ncube (R214345P) is not registered for Semester 1.', time: '1d ago' },
  { id: 'alert-005', icon: <Clock size={14} />, iconBg: 'bg-amber-100', iconColor: 'text-risk-amber', title: '6 consecutive absences', desc: 'Simbai Chikwanda (R213789K) — 6 consecutive missed lectures.', time: '2d ago' },
];

export default function RecentAlertsPanel() {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden h-full">
      <div className="px-5 py-4 border-b border-border">
        <h2 className="text-base font-600 text-foreground">Recent Alerts</h2>
        <p className="text-xs text-muted-foreground mt-0.5">System-generated risk flags</p>
      </div>
      <div className="divide-y divide-border">
        {alerts?.map((alert) => (
          <div key={alert?.id} className="flex items-start gap-3 px-5 py-3.5 hover:bg-muted/30 transition-colors">
            <div className={`p-1.5 rounded-lg flex-shrink-0 mt-0.5 ${alert?.iconBg}`}>
              <span className={alert?.iconColor}>{alert?.icon}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-600 text-foreground leading-tight">{alert?.title}</p>
              <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{alert?.desc}</p>
            </div>
            <p className="text-xs text-muted-foreground flex-shrink-0 mt-0.5">{alert?.time}</p>
          </div>
        ))}
      </div>
    </div>
  );
}