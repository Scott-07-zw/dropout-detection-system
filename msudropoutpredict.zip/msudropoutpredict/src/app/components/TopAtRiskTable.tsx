import React from 'react';
import Link from 'next/link';
import { AlertTriangle, ExternalLink } from 'lucide-react';
import { mockStudents, mockGrades, mockAttendance, computeRisk } from '@/lib/mockData';
import RiskBadge from '@/components/ui/RiskBadge';

// BACKEND INTEGRATION POINT: Fetch top at-risk students from GET /api/students/at-risk?limit=6
export default function TopAtRiskTable() {
  const atRiskStudents = mockStudents?.map((stu) => {
      const grade = mockGrades?.find((g) => g?.studentId === stu?.id);
      const attendance = mockAttendance?.filter((a) => a?.studentId === stu?.id);
      const risk = computeRisk(stu, grade, attendance);
      return { stu, risk };
    })?.filter((s) => s?.risk?.riskLevel !== 'green')?.sort((a, b) => (a?.risk?.riskLevel === 'red' ? -1 : 1))?.slice(0, 6);

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <AlertTriangle size={16} className="text-risk-amber" />
          <h2 className="text-base font-600 text-foreground">Students Requiring Attention</h2>
        </div>
        <Link href="/student-risk-overview" className="text-xs font-500 text-primary hover:underline flex items-center gap-1">
          View all <ExternalLink size={12} />
        </Link>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40">
              {['Reg Number', 'Name', 'Attendance %', 'Avg Mark', 'Coursework', 'Risk']?.map((h) => (
                <th key={`th-${h}`} className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {atRiskStudents?.map(({ stu, risk }) => (
              <tr
                key={`risk-row-${stu?.id}`}
                className={[
                  'border-b border-border last:border-0 transition-colors hover:bg-muted/30',
                  risk?.riskLevel === 'red' ? 'risk-red-row' : risk?.riskLevel === 'amber' ? 'risk-amber-row' : '',
                ]?.join(' ')}
              >
                <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{stu?.regNumber}</td>
                <td className="px-4 py-3">
                  <Link href="/student-risk-report" className="font-500 text-foreground hover:text-primary hover:underline transition-colors">
                    {stu?.firstName} {stu?.lastName}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <span className={`tabular-nums font-600 text-sm ${risk?.attendancePercent < 50 ? 'text-risk-red' : risk?.attendancePercent < 75 ? 'text-risk-amber' : 'text-risk-green'}`}>
                    {risk?.attendancePercent}%
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`tabular-nums font-600 text-sm ${risk?.averageMark < 30 ? 'text-risk-red' : risk?.averageMark < 50 ? 'text-risk-amber' : 'text-risk-green'}`}>
                    {risk?.averageMark}%
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`tabular-nums font-600 text-sm ${risk?.courseworkMark < 12 ? 'text-risk-red' : 'text-foreground'}`}>
                    {risk?.courseworkMark}/20
                  </span>
                </td>
                <td className="px-4 py-3">
                  <RiskBadge level={risk?.riskLevel} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}