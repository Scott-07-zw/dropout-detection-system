'use client';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Copy, Check, LogIn, GraduationCap } from 'lucide-react';
import { toast } from 'sonner';
import { DEMO_CREDENTIALS } from '@/lib/mockData';
import AppLogo from '@/components/ui/AppLogo';

interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

export default function LoginForm() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    setError,
  } = useForm<LoginFormData>({ defaultValues: { email: '', password: '', rememberMe: false } });

  const handleCopy = async (text: string, key: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedField(key);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleAutofill = (email: string, password: string) => {
    setValue('email', email);
    setValue('password', password);
    toast.info('Credentials filled — click Sign In to continue.');
  };

  // BACKEND INTEGRATION POINT: Replace with POST /api/auth/login
  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 1200));

    const match = DEMO_CREDENTIALS.find(
      (c) => c.email === data.email && c.password === data.password
    );

    if (!match) {
      setIsLoading(false);
      setError('email', { message: 'Invalid credentials — use the demo accounts below to sign in.' });
      return;
    }

    toast.success(`Welcome back, ${match.name}!`);
    await new Promise((r) => setTimeout(r, 500));
    router.push('/');
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-5/12 xl:w-1/2 bg-primary flex-col justify-between p-10 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-64 h-64 rounded-full border-2 border-white" />
          <div className="absolute bottom-20 right-10 w-96 h-96 rounded-full border border-white" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border-2 border-white" />
        </div>
        <div className="relative flex items-center gap-3">
          <AppLogo size={40} />
          <div>
            <p className="text-white font-700 text-lg leading-tight">MSU DropoutPredict</p>
            <p className="text-white/60 text-xs">Student Risk Management System</p>
          </div>
        </div>
        <div className="relative">
          <div className="w-16 h-1 bg-accent rounded mb-6" />
          <h1 className="text-3xl xl:text-4xl font-800 text-white leading-tight mb-4">
            Identify at-risk<br />students early.
          </h1>
          <p className="text-white/70 text-base leading-relaxed max-w-sm">
            A rule-based early warning system for Midlands State University — tracking attendance, registration, and academic performance to prevent student dropout.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4">
            {[
              { label: 'Students Monitored', value: '1,240+' },
              { label: 'Risk Rules Applied', value: '6 Rules' },
              { label: 'Modules Tracked', value: '48' },
            ].map((stat) => (
              <div key={`stat-${stat.label}`} className="bg-white/10 rounded-xl p-4">
                <p className="text-white font-700 text-xl tabular-nums">{stat.value}</p>
                <p className="text-white/60 text-xs mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="relative flex items-center gap-2">
          <GraduationCap size={16} className="text-white/40" />
          <p className="text-white/40 text-xs">Midlands State University — Gweru, Zimbabwe</p>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex flex-col justify-center px-6 sm:px-10 lg:px-16 xl:px-20 py-10 overflow-y-auto">
        <div className="max-w-md w-full mx-auto">
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <AppLogo size={32} />
            <span className="font-700 text-lg text-foreground">MSU DropoutPredict</span>
          </div>

          <h2 className="text-2xl font-700 text-foreground mb-1">Sign in to your account</h2>
          <p className="text-sm text-muted-foreground mb-8">Enter your MSU staff credentials to continue.</p>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-600 text-foreground mb-1.5">
                Email address
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@msu.ac.zw"
                className={[
                  'w-full px-4 py-2.5 rounded-lg border text-sm bg-input text-foreground placeholder:text-muted-foreground',
                  'focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all',
                  errors.email ? 'border-risk-red ring-1 ring-risk-red' : 'border-border',
                ].join(' ')}
                {...register('email', {
                  required: 'Email address is required.',
                  pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Enter a valid email address.' },
                })}
              />
              {errors.email && (
                <p className="mt-1.5 text-xs text-risk-red">{errors.email.message}</p>
              )}
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-600 text-foreground mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  placeholder="Enter your password"
                  className={[
                    'w-full px-4 py-2.5 pr-11 rounded-lg border text-sm bg-input text-foreground placeholder:text-muted-foreground',
                    'focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all',
                    errors.password ? 'border-risk-red ring-1 ring-risk-red' : 'border-border',
                  ].join(' ')}
                  {...register('password', { required: 'Password is required.' })}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((p) => !p)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && (
                <p className="mt-1.5 text-xs text-risk-red">{errors.password.message}</p>
              )}
            </div>

            {/* Remember me */}
            <div className="flex items-center gap-2">
              <input
                id="rememberMe"
                type="checkbox"
                className="w-4 h-4 rounded border-border accent-primary"
                {...register('rememberMe')}
              />
              <label htmlFor="rememberMe" className="text-sm text-muted-foreground cursor-pointer">
                Keep me signed in for 7 days
              </label>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-2.5 px-4 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                  </svg>
                  Verifying credentials…
                </>
              ) : (
                <>
                  <LogIn size={16} />
                  Sign In
                </>
              )}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-8 border border-border rounded-xl overflow-hidden">
            <div className="bg-muted px-4 py-3 border-b border-border">
              <p className="text-xs font-700 text-foreground uppercase tracking-wider">Demo Accounts</p>
              <p className="text-xs text-muted-foreground mt-0.5">Click any role to autofill credentials</p>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-4 py-2 text-xs font-600 text-muted-foreground">Role</th>
                  <th className="text-left px-4 py-2 text-xs font-600 text-muted-foreground">Email</th>
                  <th className="text-left px-4 py-2 text-xs font-600 text-muted-foreground">Password</th>
                  <th className="px-4 py-2" />
                </tr>
              </thead>
              <tbody>
                {DEMO_CREDENTIALS.map((cred) => (
                  <tr
                    key={`cred-${cred.role}`}
                    className="border-b border-border last:border-0 hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() => handleAutofill(cred.email, cred.password)}
                  >
                    <td className="px-4 py-2.5">
                      <span className={[
                        'inline-block px-2 py-0.5 rounded-full text-xs font-600',
                        cred.role === 'Admin' ? 'bg-accent/15 text-accent' :
                        cred.role === 'HOD'? 'bg-purple-100 text-purple-700' : 'bg-secondary text-primary',
                      ].join(' ')}>
                        {cred.role}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-foreground font-500 font-mono">{cred.email}</td>
                    <td className="px-4 py-2.5 text-xs text-muted-foreground font-mono">{cred.password}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); handleCopy(cred.email, `email-${cred.role}`); }}
                          className="p-1 hover:bg-muted rounded transition-colors"
                          aria-label={`Copy ${cred.role} email`}
                        >
                          {copiedField === `email-${cred.role}` ? <Check size={12} className="text-risk-green" /> : <Copy size={12} className="text-muted-foreground" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="text-xs text-muted-foreground text-center mt-6">
            © 2026 Midlands State University — Student Risk Management System v2.1
          </p>
        </div>
      </div>
    </div>
  );
}