import LoginForm from './components/LoginForm';

export default function LoginScreenPage() {
  return <LoginForm />;
}