import AppLayout from '@/components/AppLayout';
import DashboardKPIGrid from './components/DashboardKPIGrid';
import DashboardChartsRow from './components/DashboardChartsRow';
import TopAtRiskTable from './components/TopAtRiskTable';
import RecentAlertsPanel from './components/RecentAlertsPanel';

export default function DashboardPage() {
  return (
    <AppLayout userRole="lecturer" userName="Dr. Tendai Muzorewa">
      <div className="space-y-6">
        {/* Page header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-700 text-foreground">Dashboard</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Semester 1, 2026 — CS201, CS202 — Last updated 30/08/2026 16:42
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="flex items-center gap-1.5 text-xs font-500 text-risk-green bg-risk-green-bg border border-risk-green-border px-3 py-1.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-risk-green animate-pulse" />
              Live data
            </span>
          </div>
        </div>

        <DashboardKPIGrid />
        <DashboardChartsRow />

        <div className="grid grid-cols-1 xl:grid-cols-3 2xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2">
            <TopAtRiskTable />
          </div>
          <div className="xl:col-span-1">
            <RecentAlertsPanel />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}