'use client';
import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import { toast } from 'sonner';
import {
  Search, Filter, Download, ChevronUp, ChevronDown,
  AlertTriangle, Users, FileText, X,
} from 'lucide-react';
import {
  mockStudents, mockGrades, mockAttendance, mockModules,
  computeRisk,
} from '@/lib/mockData';
import RiskBadge from '@/components/ui/RiskBadge';
import type { RiskLevel } from '@/lib/mockData';

// BACKEND INTEGRATION POINT: GET /api/students/risk-overview?moduleId=&riskLevel=&page=&limit=

type SortKey = 'regNumber' | 'name' | 'attendancePercent' | 'averageMark' | 'courseworkMark' | 'consecutiveAbsences' | 'riskLevel';
type SortDir = 'asc' | 'desc';

const riskOrder: Record<RiskLevel, number> = { red: 0, amber: 1, green: 2 };

export default function RiskOverviewClient() {
  const [search, setSearch] = useState('');
  const [filterRisk, setFilterRisk] = useState<RiskLevel | 'all'>('all');
  const [filterModule, setFilterModule] = useState('all');
  const [filterRegistered, setFilterRegistered] = useState<'all' | 'registered' | 'unregistered'>('all');
  const [sortKey, setSortKey] = useState<SortKey>('riskLevel');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(1);
  const pageSize = 10;

  // Build combined data
  const allRows = useMemo(() => {
    return mockStudents.map((stu) => {
      const grade = mockGrades.find((g) => g.studentId === stu.id);
      const attendance = mockAttendance.filter((a) => a.studentId === stu.id);
      const risk = computeRisk(stu, grade, attendance);
      const module = grade ? mockModules.find((m) => m.id === grade.moduleId) : null;
      return { stu, grade, risk, module };
    });
  }, []);

  const filtered = useMemo(() => {
    let rows = allRows;
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.stu.firstName.toLowerCase().includes(q) ||
          r.stu.lastName.toLowerCase().includes(q) ||
          r.stu.regNumber.toLowerCase().includes(q)
      );
    }
    if (filterRisk !== 'all') rows = rows.filter((r) => r.risk.riskLevel === filterRisk);
    if (filterModule !== 'all') rows = rows.filter((r) => r.module?.id === filterModule);
    if (filterRegistered === 'registered') rows = rows.filter((r) => r.stu.isRegistered);
    if (filterRegistered === 'unregistered') rows = rows.filter((r) => !r.stu.isRegistered);
    return rows;
  }, [allRows, search, filterRisk, filterModule, filterRegistered]);

  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let cmp = 0;
      switch (sortKey) {
        case 'regNumber': cmp = a.stu.regNumber.localeCompare(b.stu.regNumber); break;
        case 'name': cmp = a.stu.lastName.localeCompare(b.stu.lastName); break;
        case 'attendancePercent': cmp = a.risk.attendancePercent - b.risk.attendancePercent; break;
        case 'averageMark': cmp = a.risk.averageMark - b.risk.averageMark; break;
        case 'courseworkMark': cmp = a.risk.courseworkMark - b.risk.courseworkMark; break;
        case 'consecutiveAbsences': cmp = a.risk.consecutiveAbsences - b.risk.consecutiveAbsences; break;
        case 'riskLevel': cmp = riskOrder[a.risk.riskLevel] - riskOrder[b.risk.riskLevel]; break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });
  }, [filtered, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const paginated = sorted.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir('asc'); }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === paginated.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(paginated.map((r) => r.stu.id)));
  };

  const handleExport = () => {
    // BACKEND INTEGRATION POINT: POST /api/reports/export { studentIds: [...] }
    toast.success(`Exporting ${selectedIds.size > 0 ? selectedIds.size : sorted.length} student records as CSV.`);
  };

  const handleBulkEscalate = () => {
    toast.success(`${selectedIds.size} student(s) escalated to HOD for review.`);
    setSelectedIds(new Set());
  };

  const SortIcon = ({ col }: { col: SortKey }) =>
    sortKey === col ? (
      sortDir === 'asc' ? <ChevronUp size={12} className="text-primary" /> : <ChevronDown size={12} className="text-primary" />
    ) : (
      <ChevronDown size={12} className="text-muted-foreground/40" />
    );

  const redCount = allRows.filter((r) => r.risk.riskLevel === 'red').length;
  const amberCount = allRows.filter((r) => r.risk.riskLevel === 'amber').length;
  const greenCount = allRows.filter((r) => r.risk.riskLevel === 'green').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-700 text-foreground">Student Risk Overview</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Department-wide risk assessment — Computer Science — Semester 1, 2026
          </p>
        </div>
        <button
          onClick={handleExport}
          className="flex items-center gap-2 border border-border bg-card text-foreground px-4 py-2 rounded-lg text-sm font-600 hover:bg-muted transition-colors self-start sm:self-auto"
        >
          <Download size={15} />
          Export CSV
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 sm:grid-cols-3 gap-4">
        {[
          { id: 'sum-red', label: 'High Risk', count: redCount, cls: 'border-risk-red bg-risk-red-bg', textCls: 'text-risk-red', dotCls: 'bg-risk-red' },
          { id: 'sum-amber', label: 'Moderate Risk', count: amberCount, cls: 'border-risk-amber bg-risk-amber-bg', textCls: 'text-risk-amber', dotCls: 'bg-risk-amber' },
          { id: 'sum-green', label: 'No Risk', count: greenCount, cls: 'border-risk-green bg-risk-green-bg', textCls: 'text-risk-green', dotCls: 'bg-risk-green' },
        ].map((s) => (
          <button
            key={s.id}
            onClick={() => { setFilterRisk(s.id === 'sum-red' ? 'red' : s.id === 'sum-amber' ? 'amber' : 'green'); setPage(1); }}
            className={`rounded-xl border-2 p-4 text-left transition-all hover:shadow-md active:scale-95 ${s.cls}`}
          >
            <div className="flex items-center gap-2 mb-1">
              <span className={`w-2 h-2 rounded-full ${s.dotCls}`} />
              <span className="text-xs font-600 text-muted-foreground uppercase tracking-wider">{s.label}</span>
            </div>
            <p className={`text-3xl font-700 tabular-nums ${s.textCls}`}>{s.count}</p>
            <p className="text-xs text-muted-foreground mt-1">Click to filter</p>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-48">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by name or reg number…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-8 pr-3 py-2 text-sm bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div className="relative">
            <select
              value={filterRisk}
              onChange={(e) => { setFilterRisk(e.target.value as RiskLevel | 'all'); setPage(1); }}
              className="appearance-none bg-input border border-border rounded-lg px-3 py-2 text-sm font-500 text-foreground focus:outline-none focus:ring-2 focus:ring-ring pr-7"
            >
              <option value="all">All Risk Levels</option>
              <option value="red">High Risk</option>
              <option value="amber">Moderate Risk</option>
              <option value="green">No Risk</option>
            </select>
            <Filter size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={filterModule}
              onChange={(e) => { setFilterModule(e.target.value); setPage(1); }}
              className="appearance-none bg-input border border-border rounded-lg px-3 py-2 text-sm font-500 text-foreground focus:outline-none focus:ring-2 focus:ring-ring pr-7"
            >
              <option value="all">All Modules</option>
              {mockModules.map((m) => (
                <option key={`mod-filter-${m.id}`} value={m.id}>{m.code} — {m.name}</option>
              ))}
            </select>
            <Filter size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={filterRegistered}
              onChange={(e) => { setFilterRegistered(e.target.value as 'all' | 'registered' | 'unregistered'); setPage(1); }}
              className="appearance-none bg-input border border-border rounded-lg px-3 py-2 text-sm font-500 text-foreground focus:outline-none focus:ring-2 focus:ring-ring pr-7"
            >
              <option value="all">All Registration</option>
              <option value="registered">Registered</option>
              <option value="unregistered">Unregistered</option>
            </select>
            <Filter size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
          {(filterRisk !== 'all' || filterModule !== 'all' || filterRegistered !== 'all' || search) && (
            <button
              onClick={() => { setFilterRisk('all'); setFilterModule('all'); setFilterRegistered('all'); setSearch(''); setPage(1); }}
              className="flex items-center gap-1.5 text-sm font-500 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X size={14} />
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Bulk action bar */}
      {selectedIds.size > 0 && (
        <div className="flex items-center gap-4 bg-primary text-primary-foreground px-5 py-3 rounded-xl fade-in">
          <span className="text-sm font-600">{selectedIds.size} student{selectedIds.size > 1 ? 's' : ''} selected</span>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={handleBulkEscalate}
              className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white px-3 py-1.5 rounded-lg text-sm font-500 transition-colors"
            >
              <AlertTriangle size={13} />
              Escalate to HOD
            </button>
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white px-3 py-1.5 rounded-lg text-sm font-500 transition-colors"
            >
              <Download size={13} />
              Export Selected
            </button>
            <button
              onClick={() => setSelectedIds(new Set())}
              className="p-1.5 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Users size={15} className="text-muted-foreground" />
            <span className="text-sm font-600 text-foreground">
              {sorted.length} student{sorted.length !== 1 ? 's' : ''}
            </span>
            {filtered.length !== allRows.length && (
              <span className="text-xs text-muted-foreground">(filtered from {allRows.length})</span>
            )}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="px-4 py-3 w-10">
                  <input
                    type="checkbox"
                    checked={selectedIds.size === paginated.length && paginated.length > 0}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded border-border accent-primary"
                    aria-label="Select all visible rows"
                  />
                </th>
                {([
                  { key: 'regNumber', label: 'Reg Number' },
                  { key: 'name', label: 'Student Name' },
                  { key: null, label: 'Module' },
                  { key: null, label: 'Registered' },
                  { key: 'attendancePercent', label: 'Attendance %' },
                  { key: 'consecutiveAbsences', label: 'Consec. Absent' },
                  { key: 'courseworkMark', label: 'Coursework' },
                  { key: 'averageMark', label: 'Avg Mark' },
                  { key: 'riskLevel', label: 'Risk Level' },
                  { key: null, label: 'Actions' },
                ] as { key: SortKey | null; label: string }[]).map((col) => (
                  <th
                    key={`overview-th-${col.label}`}
                    className={[
                      'text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wider whitespace-nowrap',
                      col.key ? 'cursor-pointer hover:text-foreground select-none' : '',
                    ].join(' ')}
                    onClick={() => col.key && handleSort(col.key)}
                  >
                    <span className="flex items-center gap-1">
                      {col.label}
                      {col.key && <SortIcon col={col.key} />}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-4 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Users size={32} className="text-muted-foreground/40" />
                      <p className="text-sm font-600 text-foreground">No students match your filters</p>
                      <p className="text-xs text-muted-foreground">Try adjusting the risk level, module, or registration filter above.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                paginated.map(({ stu, risk, module }) => (
                  <tr
                    key={`overview-row-${stu.id}`}
                    className={[
                      'border-b border-border last:border-0 transition-colors hover:bg-muted/20 group',
                      risk.riskLevel === 'red' ? 'risk-red-row' : risk.riskLevel === 'amber' ? 'risk-amber-row' : '',
                    ].join(' ')}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selectedIds.has(stu.id)}
                        onChange={() => toggleSelect(stu.id)}
                        className="w-4 h-4 rounded border-border accent-primary"
                        aria-label={`Select ${stu.firstName} ${stu.lastName}`}
                      />
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground whitespace-nowrap">{stu.regNumber}</td>
                    <td className="px-4 py-3">
                      <p className="font-600 text-foreground text-sm whitespace-nowrap">{stu.firstName} {stu.lastName}</p>
                      <p className="text-xs text-muted-foreground">{stu.programme} — Yr {stu.year}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                      {module ? `${module.code}` : '—'}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-600 ${stu.isRegistered ? 'risk-green-badge' : 'risk-red-badge'}`}>
                        {stu.isRegistered ? '✓' : '✗'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`tabular-nums font-700 text-sm ${risk.attendancePercent < 50 ? 'text-risk-red' : risk.attendancePercent < 75 ? 'text-risk-amber' : 'text-risk-green'}`}>
                        {risk.attendancePercent}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`tabular-nums font-700 text-sm ${risk.consecutiveAbsences >= 10 ? 'text-risk-red' : risk.consecutiveAbsences >= 5 ? 'text-risk-amber' : 'text-foreground'}`}>
                        {risk.consecutiveAbsences}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`tabular-nums font-700 text-sm ${risk.courseworkMark < 12 ? 'text-risk-red' : 'text-foreground'}`}>
                        {risk.courseworkMark}/20
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`tabular-nums font-700 text-sm ${risk.averageMark < 30 ? 'text-risk-red' : risk.averageMark < 50 ? 'text-risk-amber' : 'text-risk-green'}`}>
                        {risk.averageMark}%
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <RiskBadge level={risk.riskLevel} size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Link
                          href="/student-risk-report"
                          title="View full risk report"
                          className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                        >
                          <FileText size={14} />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-5 py-4 border-t border-border bg-muted/20">
          <p className="text-xs text-muted-foreground">
            Showing {Math.min((page - 1) * pageSize + 1, sorted.length)}–{Math.min(page * pageSize, sorted.length)} of {sorted.length} students
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-3 py-1.5 text-xs font-500 rounded-lg border border-border bg-card hover:bg-muted transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={`page-${p}`}
                onClick={() => setPage(p)}
                className={[
                  'w-8 h-8 text-xs font-600 rounded-lg transition-colors',
                  p === page ? 'bg-primary text-primary-foreground' : 'border border-border bg-card hover:bg-muted text-foreground',
                ].join(' ')}
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-3 py-1.5 text-xs font-500 rounded-lg border border-border bg-card hover:bg-muted transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}