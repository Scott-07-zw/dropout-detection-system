import AppLayout from '@/components/AppLayout';
import RiskOverviewClient from './components/RiskOverviewClient';

export default function StudentRiskOverviewPage() {
  return (
    <AppLayout userRole="hod" userName="Prof. Nomsa Dube">
      <RiskOverviewClient />
    </AppLayout>
  );
}