'use client';
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import type { AttendanceRecord } from '@/lib/mockData';

interface Props {
  attendance: AttendanceRecord[];
}

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg shadow-lg px-3 py-2">
      <p className="text-xs font-600 text-foreground">Session {label}</p>
      <p className="text-xs text-muted-foreground">{payload[0].value === 1 ? 'Present' : 'Absent'}</p>
    </div>
  );
};

export default function StudentAttendanceChart({ attendance }: Props) {
  const data = attendance
    .sort((a, b) => a.sessionNumber - b.sessionNumber)
    .map((a) => ({ session: a.sessionNumber, present: a.present ? 1 : 0 }));

  return (
    <ResponsiveContainer width="100%" height={160}>
      <BarChart data={data} margin={{ top: 4, right: 4, left: -30, bottom: 0 }}>
        <XAxis dataKey="session" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} label={{ value: 'Session', position: 'insideBottom', offset: -2, fontSize: 10, fill: 'var(--muted-foreground)' }} />
        <YAxis hide domain={[0, 1]} />
        <Tooltip content={<CustomTooltip />} />
        <Bar dataKey="present" radius={[3, 3, 0, 0]}>
          {data.map((entry) => (
            <Cell key={`cell-att-${entry.session}`} fill={entry.present === 1 ? 'var(--risk-green)' : 'var(--risk-red)'}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}