'use client';
import React, { useState } from 'react';
import { toast } from 'sonner';
import {
  FileText, AlertTriangle, CheckCircle, XCircle,
  TrendingDown, User, ChevronDown, Printer, MessageSquare,
} from 'lucide-react';
import { mockStudents, mockGrades, mockAttendance, mockModules, computeRisk } from '@/lib/mockData';
import RiskBadge from '@/components/ui/RiskBadge';
import dynamic from 'next/dynamic';

const StudentAttendanceChart = dynamic(() => import('./StudentAttendanceChart'), { ssr: false });

// BACKEND INTEGRATION POINT: GET /api/students/:id/risk-report

const NOTES_INITIAL = [
  { id: 'note-001', author: 'Dr. T. Muzorewa', date: '28/08/2026', text: 'Student contacted via email. No response received. Will escalate to HOD if no response by 05/09/2026.' },
];

export default function StudentRiskReportClient() {
  const [selectedStudentId, setSelectedStudentId] = useState('stu-008');
  const [noteText, setNoteText] = useState('');
  const [notes, setNotes] = useState(NOTES_INITIAL);
  const [isGenerating, setIsGenerating] = useState(false);

  const student = mockStudents.find((s) => s.id === selectedStudentId)!;
  const grade = mockGrades.find((g) => g.studentId === selectedStudentId);
  const attendance = mockAttendance.filter((a) => a.studentId === selectedStudentId);
  const module = grade ? mockModules.find((m) => m.id === grade.moduleId) : null;
  const risk = computeRisk(student, grade, attendance);

  const attended = attendance.filter((a) => a.present).length;
  const avgMark = grade ? Math.round((grade.test1Mark + grade.test2Mark + grade.assignmentMark) / 3) : 0;

  const handleAddNote = () => {
    if (!noteText.trim()) return;
    const newNote = {
      id: `note-${Date.now()}`,
      author: 'Dr. T. Muzorewa',
      date: '30/08/2026',
      text: noteText.trim(),
    };
    setNotes((prev) => [newNote, ...prev]);
    setNoteText('');
    toast.success('Note added to student record.');
  };

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    // BACKEND INTEGRATION POINT: POST /api/reports/generate { studentId, moduleId }
    await new Promise((r) => setTimeout(r, 2000));
    setIsGenerating(false);
    toast.success(`PDF report generated for ${student.firstName} ${student.lastName}.`);
  };

  const factorCards = [
    {
      id: 'factor-financial',
      title: 'Financial / Registration',
      icon: <User size={16} />,
      status: student.isRegistered ? 'pass' : 'fail',
      statusLabel: student.isRegistered ? 'Registered' : 'NOT Registered',
      details: student.isRegistered
        ? 'Student is registered for Semester 1, 2026. No financial risk detected.'
        : 'Student is NOT registered for Semester 1, 2026. This is an automatic HIGH RISK flag.',
      metric: student.isRegistered ? 'Registered ✓' : 'Unregistered ✗',
      metricColor: student.isRegistered ? 'text-risk-green' : 'text-risk-red',
    },
    {
      id: 'factor-academic',
      title: 'Academic Performance',
      icon: <TrendingDown size={16} />,
      status: avgMark < 30 || (grade?.courseworkMark ?? 0) < 12 ? 'fail' : avgMark < 50 ? 'warn' : 'pass',
      statusLabel: avgMark < 30 ? 'Failing' : avgMark < 50 ? 'Borderline' : 'Passing',
      details: `Average mark: ${avgMark}%. Coursework: ${grade?.courseworkMark ?? 0}/20. Test 1: ${grade?.test1Mark ?? 0}%. Test 2: ${grade?.test2Mark ?? 0}%. Assignment: ${grade?.assignmentMark ?? 0}%.`,
      metric: `${avgMark}% avg`,
      metricColor: avgMark < 30 ? 'text-risk-red' : avgMark < 50 ? 'text-risk-amber' : 'text-risk-green',
    },
    {
      id: 'factor-attendance',
      title: 'Attendance / Behaviour',
      icon: <AlertTriangle size={16} />,
      status: risk.consecutiveAbsences >= 10 ? 'fail' : risk.consecutiveAbsences >= 5 || risk.attendancePercent < 50 ? 'warn' : 'pass',
      statusLabel: risk.consecutiveAbsences >= 10 ? 'Critical' : risk.consecutiveAbsences >= 5 ? 'Warning' : 'Acceptable',
      details: `Attended ${attended}/${attendance.length} sessions (${risk.attendancePercent}%). ${risk.consecutiveAbsences > 0 ? `${risk.consecutiveAbsences} consecutive absences recorded.` : 'No consecutive absences.'}`,
      metric: `${risk.attendancePercent}% attended`,
      metricColor: risk.attendancePercent < 50 ? 'text-risk-red' : risk.attendancePercent < 75 ? 'text-risk-amber' : 'text-risk-green',
    },
  ];

  const statusIconMap = {
    pass: <CheckCircle size={14} className="text-risk-green" />,
    warn: <AlertTriangle size={14} className="text-risk-amber" />,
    fail: <XCircle size={14} className="text-risk-red" />,
  };

  const statusBgMap = {
    pass: 'border-risk-green bg-risk-green-bg',
    warn: 'border-risk-amber bg-risk-amber-bg',
    fail: 'border-risk-red bg-risk-red-bg',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-700 text-foreground">Student Risk Report</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Rule-based dropout risk assessment</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative">
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="appearance-none bg-input border border-border rounded-lg px-3 py-2 text-sm font-500 text-foreground focus:outline-none focus:ring-2 focus:ring-ring pr-8"
            >
              {mockStudents.map((s) => (
                <option key={`stu-opt-${s.id}`} value={s.id}>
                  {s.regNumber} — {s.firstName} {s.lastName}
                </option>
              ))}
            </select>
            <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
          <button
            onClick={handleGenerateReport}
            disabled={isGenerating}
            className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-60"
          >
            {isGenerating ? (
              <>
                <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                </svg>
                Generating…
              </>
            ) : (
              <>
                <Printer size={16} />
                Generate PDF Report
              </>
            )}
          </button>
        </div>
      </div>

      {/* Student profile header */}
      <div className={`rounded-xl border-2 p-6 ${risk.riskLevel === 'red' ? 'border-risk-red bg-risk-red-bg' : risk.riskLevel === 'amber' ? 'border-risk-amber bg-risk-amber-bg' : 'border-risk-green bg-risk-green-bg'}`}>
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-xl font-700 text-primary-foreground flex-shrink-0">
            {student.firstName[0]}{student.lastName[0]}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-3 mb-1">
              <h2 className="text-xl font-700 text-foreground">{student.firstName} {student.lastName}</h2>
              <RiskBadge level={risk.riskLevel} size="lg" />
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
              <span className="font-mono font-600">{student.regNumber}</span>
              <span>{student.programme}</span>
              <span>Year {student.year}</span>
              <span>{student.department}</span>
              {module && <span>{module.code} — {module.name}</span>}
            </div>
          </div>
          <div className="flex-shrink-0 text-right">
            <p className="text-xs text-muted-foreground">Report generated</p>
            <p className="text-sm font-600 text-foreground">30/08/2026 18:29</p>
          </div>
        </div>
      </div>

      {/* Risk reasons */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <FileText size={16} className="text-primary" />
          <h2 className="text-base font-600 text-foreground">Risk Assessment Summary</h2>
        </div>
        <div className="space-y-3">
          {risk.riskReasons.map((reason, i) => (
            <div key={`reason-${i}`} className="flex items-start gap-3">
              <span className="flex-shrink-0 mt-0.5">
                {risk.riskLevel === 'red' ? <XCircle size={16} className="text-risk-red" /> :
                 risk.riskLevel === 'amber' ? <AlertTriangle size={16} className="text-risk-amber" /> :
                 <CheckCircle size={16} className="text-risk-green" />}
              </span>
              <p className="text-sm text-foreground leading-relaxed">{reason}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Factor cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {factorCards.map((card) => (
          <div key={card.id} className={`rounded-xl border-2 p-5 ${statusBgMap[card.status as keyof typeof statusBgMap]}`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">{card.icon}</span>
                <h3 className="text-sm font-600 text-foreground">{card.title}</h3>
              </div>
              {statusIconMap[card.status as keyof typeof statusIconMap]}
            </div>
            <p className={`text-2xl font-700 tabular-nums mb-1 ${card.metricColor}`}>{card.metric}</p>
            <span className={`text-xs font-600 px-2 py-0.5 rounded-full ${
              card.status === 'pass' ? 'risk-green-badge' : card.status === 'warn' ? 'risk-amber-badge' : 'risk-red-badge'
            }`}>
              {card.statusLabel}
            </span>
            <p className="text-xs text-muted-foreground mt-3 leading-relaxed">{card.details}</p>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-base font-600 text-foreground mb-1">Attendance History</h2>
          <p className="text-xs text-muted-foreground mb-4">Session-by-session record — {module?.code}</p>
          <StudentAttendanceChart attendance={attendance} />
        </div>
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="text-base font-600 text-foreground mb-1">Grade Breakdown</h2>
          <p className="text-xs text-muted-foreground mb-4">Assessment results — {module?.code}</p>
          {grade ? (
            <div className="space-y-3">
              {[
                { label: 'Coursework', mark: grade.courseworkMark, max: 20, threshold: 12, thresholdLabel: 'min 12' },
                { label: 'Test 1', mark: grade.test1Mark, max: 100, threshold: 50, thresholdLabel: 'pass 50%' },
                { label: 'Test 2', mark: grade.test2Mark, max: 100, threshold: 50, thresholdLabel: 'pass 50%' },
                { label: 'Assignment', mark: grade.assignmentMark, max: 100, threshold: 50, thresholdLabel: 'pass 50%' },
              ].map((item) => {
                const pct = Math.round((item.mark / item.max) * 100);
                const passing = item.mark >= item.threshold;
                return (
                  <div key={`grade-bar-${item.label}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-500 text-foreground">{item.label}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">{item.thresholdLabel}</span>
                        <span className={`text-sm font-700 tabular-nums ${!passing ? 'text-risk-red' : 'text-risk-green'}`}>
                          {item.mark}/{item.max}
                        </span>
                      </div>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: !passing ? 'var(--risk-red)' : pct < 65 ? 'var(--risk-amber)' : 'var(--risk-green)',
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No grade data available for this student.</p>
          )}
        </div>
      </div>

      {/* Lecturer notes */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <MessageSquare size={16} className="text-primary" />
          <h2 className="text-base font-600 text-foreground">Lecturer Notes</h2>
        </div>
        <div className="space-y-3 mb-4">
          {notes.map((note) => (
            <div key={note.id} className="bg-muted/40 border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-600 text-foreground">{note.author}</p>
                <p className="text-xs text-muted-foreground">{note.date}</p>
              </div>
              <p className="text-sm text-foreground leading-relaxed">{note.text}</p>
            </div>
          ))}
        </div>
        <div className="flex gap-3">
          <textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Add a note about this student — e.g. intervention taken, communication attempts, escalation status…"
            rows={3}
            className="flex-1 px-3 py-2 text-sm bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
          />
          <button
            onClick={handleAddNote}
            disabled={!noteText.trim()}
            className="self-end flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Add Note
          </button>
        </div>
      </div>
    </div>
  );
}