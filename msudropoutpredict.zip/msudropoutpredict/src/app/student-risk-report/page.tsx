import AppLayout from '@/components/AppLayout';
import StudentRiskReportClient from './components/StudentRiskReportClient';

export default function StudentRiskReportPage() {
  return (
    <AppLayout userRole="lecturer" userName="Dr. Tendai Muzorewa">
      <StudentRiskReportClient />
    </AppLayout>
  );
}