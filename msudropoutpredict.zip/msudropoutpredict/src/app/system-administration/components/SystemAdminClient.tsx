'use client';
import React, { useState } from 'react';
import { toast } from 'sonner';
import { Users, Upload, Settings, ClipboardList, Plus, Trash2, CheckCircle, XCircle, Shield, AlertTriangle, Save, RefreshCw,  } from 'lucide-react';
import { mockLecturers, mockAuditLogs } from '@/lib/mockData';
import ConfirmModal from '@/components/ui/ConfirmModal';

// BACKEND INTEGRATION POINT: All mutations → POST/PUT/DELETE /api/admin/...

type AdminTab = 'accounts' | 'import' | 'thresholds' | 'audit';

const TAB_LIST: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
  { id: 'accounts', label: 'Lecturer Accounts', icon: <Users size={15} /> },
  { id: 'import', label: 'Student Data Import', icon: <Upload size={15} /> },
  { id: 'thresholds', label: 'Risk Rule Thresholds', icon: <Settings size={15} /> },
  { id: 'audit', label: 'Audit Log', icon: <ClipboardList size={15} /> },
];

interface Thresholds {
  academicFailMark: number;
  courseworkMinMark: number;
  consecutiveAbsenceWarning: number;
  consecutiveAbsenceRed: number;
  attendanceWarningPct: number;
}

const DEFAULT_THRESHOLDS: Thresholds = {
  academicFailMark: 30,
  courseworkMinMark: 12,
  consecutiveAbsenceWarning: 5,
  consecutiveAbsenceRed: 10,
  attendanceWarningPct: 50,
};

export default function SystemAdminClient() {
  const [activeTab, setActiveTab] = useState<AdminTab>('accounts');
  const [lecturers, setLecturers] = useState(mockLecturers);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [thresholds, setThresholds] = useState<Thresholds>(DEFAULT_THRESHOLDS);
  const [isSavingThresholds, setIsSavingThresholds] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [importFile, setImportFile] = useState<string | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newLecturer, setNewLecturer] = useState({ name: '', email: '', role: 'lecturer', department: 'Computer Science' });

  const handleDeactivate = (id: string) => {
    setLecturers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, status: l.status === 'active' ? 'inactive' : 'active' } : l))
    );
    const lec = lecturers.find((l) => l.id === id);
    toast.success(`${lec?.name} account ${lec?.status === 'active' ? 'deactivated' : 'activated'}.`);
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    const lec = lecturers.find((l) => l.id === deleteTarget);
    setLecturers((prev) => prev.filter((l) => l.id !== deleteTarget));
    setDeleteTarget(null);
    toast.success(`${lec?.name} account deleted from the system.`);
  };

  const handleCreateLecturer = () => {
    if (!newLecturer.name || !newLecturer.email) {
      toast.error('Name and email are required.');
      return;
    }
    const created = {
      id: `lec-${Date.now()}`,
      name: newLecturer.name,
      email: newLecturer.email,
      role: newLecturer.role as 'lecturer' | 'hod' | 'admin',
      department: newLecturer.department,
      modulesCount: 0,
      status: 'active' as const,
      lastLogin: 'Never',
    };
    setLecturers((prev) => [created, ...prev]);
    setNewLecturer({ name: '', email: '', role: 'lecturer', department: 'Computer Science' });
    setShowCreateForm(false);
    toast.success(`Account created for ${created.name}.`);
  };

  const handleSaveThresholds = async () => {
    setIsSavingThresholds(true);
    // BACKEND INTEGRATION POINT: PUT /api/admin/thresholds
    await new Promise((r) => setTimeout(r, 1000));
    setIsSavingThresholds(false);
    toast.success('Risk rule thresholds updated. All student risk scores will be recalculated.');
  };

  const handleImport = async () => {
    if (!importFile) return;
    setIsImporting(true);
    // BACKEND INTEGRATION POINT: POST /api/admin/students/import (multipart/form-data)
    await new Promise((r) => setTimeout(r, 2000));
    setIsImporting(false);
    setImportFile(null);
    toast.success('12 student records imported successfully from CSV.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-700 text-foreground">System Administration</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage accounts, import data, and configure risk rules
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-accent/10 border border-accent/30 rounded-lg">
          <Shield size={14} className="text-accent" />
          <span className="text-xs font-600 text-accent">Admin Access</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-muted p-1 rounded-xl overflow-x-auto">
        {TAB_LIST.map((tab) => (
          <button
            key={`tab-${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
            className={[
              'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-600 transition-all whitespace-nowrap',
              activeTab === tab.id
                ? 'bg-card text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground',
            ].join(' ')}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── ACCOUNTS TAB ── */}
      {activeTab === 'accounts' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{lecturers.length} accounts in the system</p>
            <button
              onClick={() => setShowCreateForm((p) => !p)}
              className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all"
            >
              <Plus size={15} />
              Create Account
            </button>
          </div>

          {showCreateForm && (
            <div className="bg-card border border-border rounded-xl p-5 fade-in">
              <h3 className="text-sm font-700 text-foreground mb-4">New Lecturer Account</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xs font-600 text-foreground mb-1.5">Full Name</label>
                  <input
                    type="text"
                    value={newLecturer.name}
                    onChange={(e) => setNewLecturer((p) => ({ ...p, name: e.target.value }))}
                    placeholder="Dr. Firstname Lastname"
                    className="w-full px-3 py-2 text-sm bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div>
                  <label className="block text-xs font-600 text-foreground mb-1.5">Email Address</label>
                  <input
                    type="email"
                    value={newLecturer.email}
                    onChange={(e) => setNewLecturer((p) => ({ ...p, email: e.target.value }))}
                    placeholder="name@msu.ac.zw"
                    className="w-full px-3 py-2 text-sm bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div>
                  <label className="block text-xs font-600 text-foreground mb-1.5">Role</label>
                  <select
                    value={newLecturer.role}
                    onChange={(e) => setNewLecturer((p) => ({ ...p, role: e.target.value }))}
                    className="w-full px-3 py-2 text-sm bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="lecturer">Lecturer</option>
                    <option value="hod">Head of Department</option>
                    <option value="admin">System Administrator</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-600 text-foreground mb-1.5">Department</label>
                  <select
                    value={newLecturer.department}
                    onChange={(e) => setNewLecturer((p) => ({ ...p, department: e.target.value }))}
                    className="w-full px-3 py-2 text-sm bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option>Computer Science</option>
                    <option>Mathematics</option>
                    <option>Physics</option>
                    <option>Engineering</option>
                  </select>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleCreateLecturer}
                  className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all"
                >
                  <CheckCircle size={14} />
                  Create Account
                </button>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-2 text-sm font-500 text-muted-foreground hover:text-foreground transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    {['Name', 'Email', 'Role', 'Department', 'Modules', 'Status', 'Last Login', 'Actions'].map((h) => (
                      <th key={`admin-th-${h}`} className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {lecturers.map((lec) => (
                    <tr key={`lec-row-${lec.id}`} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors group">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-700 text-primary flex-shrink-0">
                            {lec.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                          </div>
                          <span className="font-600 text-foreground whitespace-nowrap">{lec.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground font-mono">{lec.email}</td>
                      <td className="px-4 py-3">
                        <span className={[
                          'inline-flex px-2 py-0.5 rounded-full text-xs font-600',
                          lec.role === 'admin' ? 'bg-accent/15 text-accent' :
                          lec.role === 'hod'? 'bg-purple-100 text-purple-700' : 'bg-secondary text-primary',
                        ].join(' ')}>
                          {lec.role === 'hod' ? 'HOD' : lec.role === 'admin' ? 'Admin' : 'Lecturer'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{lec.department}</td>
                      <td className="px-4 py-3 text-center tabular-nums text-sm font-600 text-foreground">{lec.modulesCount}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-600 ${lec.status === 'active' ? 'risk-green-badge' : 'bg-muted text-muted-foreground border border-border'}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${lec.status === 'active' ? 'bg-risk-green' : 'bg-muted-foreground'}`} />
                          {lec.status === 'active' ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{lec.lastLogin}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleDeactivate(lec.id)}
                            title={lec.status === 'active' ? 'Deactivate account' : 'Reactivate account'}
                            className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                          >
                            {lec.status === 'active' ? <XCircle size={14} /> : <CheckCircle size={14} />}
                          </button>
                          <button
                            onClick={() => setDeleteTarget(lec.id)}
                            title="Delete account — this cannot be undone"
                            className="p-1.5 rounded-lg hover:bg-red-50 transition-colors text-muted-foreground hover:text-risk-red"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── IMPORT TAB ── */}
      {activeTab === 'import' && (
        <div className="space-y-5">
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="text-base font-700 text-foreground mb-1">Import Student Registration Data</h2>
            <p className="text-sm text-muted-foreground mb-5">
              Upload a CSV file exported from the MSU Student Registry system. Supported columns: RegNumber, FirstName, LastName, Email, Programme, Year, Department, IsRegistered.
            </p>
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragOver(false);
                const file = e.dataTransfer.files[0];
                if (file) setImportFile(file.name);
              }}
              className={[
                'border-2 border-dashed rounded-xl p-10 text-center transition-all cursor-pointer',
                isDragOver ? 'border-primary bg-secondary/50' : importFile ? 'border-risk-green bg-risk-green-bg' : 'border-border hover:border-primary/50 hover:bg-muted/30',
              ].join(' ')}
              onClick={() => {
                // BACKEND INTEGRATION POINT: trigger file input click
                setImportFile('students_sem1_2026.csv');
              }}
            >
              {importFile ? (
                <>
                  <CheckCircle size={32} className="text-risk-green mx-auto mb-3" />
                  <p className="text-sm font-600 text-foreground">{importFile}</p>
                  <p className="text-xs text-muted-foreground mt-1">Ready to import — click Import below</p>
                </>
              ) : (
                <>
                  <Upload size={32} className="text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm font-600 text-foreground">Drop CSV file here or click to browse</p>
                  <p className="text-xs text-muted-foreground mt-1">Accepts .csv files only — max 10MB</p>
                </>
              )}
            </div>
            {importFile && (
              <div className="flex items-center gap-3 mt-4">
                <button
                  onClick={handleImport}
                  disabled={isImporting}
                  className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-60"
                >
                  {isImporting ? (
                    <>
                      <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                      </svg>
                      Importing…
                    </>
                  ) : (
                    <><Upload size={15} />Import Students</>
                  )}
                </button>
                <button
                  onClick={() => setImportFile(null)}
                  className="text-sm font-500 text-muted-foreground hover:text-foreground transition-colors"
                >
                  Remove file
                </button>
              </div>
            )}
          </div>

          {/* Import format guide */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-700 text-foreground mb-3">Expected CSV Format</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs border border-border rounded-lg overflow-hidden">
                <thead>
                  <tr className="bg-muted/60">
                    {['RegNumber', 'FirstName', 'LastName', 'Email', 'Programme', 'Year', 'Department', 'IsRegistered'].map((h) => (
                      <th key={`csv-th-${h}`} className="text-left px-3 py-2 font-600 text-foreground border-b border-border">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-border">
                    {['R213456H', 'Takudzwa', 'Moyo', 'takudzwa@students.msu.ac.zw', 'BSc Computer Science', '2', 'Computer Science', 'TRUE'].map((v, i) => (
                      <td key={`csv-ex1-${i}`} className="px-3 py-2 font-mono text-muted-foreground">{v}</td>
                    ))}
                  </tr>
                  <tr>
                    {['R214012L', 'Nyasha', 'Dzingai', 'nyasha@students.msu.ac.zw', 'BSc Computer Science', '2', 'Computer Science', 'FALSE'].map((v, i) => (
                      <td key={`csv-ex2-${i}`} className="px-3 py-2 font-mono text-muted-foreground">{v}</td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── THRESHOLDS TAB ── */}
      {activeTab === 'thresholds' && (
        <div className="space-y-5">
          <div className="bg-amber-50 border border-risk-amber-border rounded-xl p-4 flex items-start gap-3">
            <AlertTriangle size={16} className="text-risk-amber flex-shrink-0 mt-0.5" />
            <p className="text-sm text-foreground">
              Changing these thresholds will immediately affect all student risk scores across the system. Ensure changes are reviewed by the HOD before saving.
            </p>
          </div>

          <div className="bg-card border border-border rounded-xl p-6 space-y-6">
            <h2 className="text-base font-700 text-foreground">Risk Rule Thresholds</h2>

            {[
              {
                id: 'thresh-academic',
                key: 'academicFailMark' as keyof Thresholds,
                label: 'Academic Failure Mark (%)',
                description: 'Students with an average mark below this value are flagged Amber (if registered and attending) or escalated based on other rules.',
                unit: '%',
                min: 10, max: 50, step: 5,
                ruleText: 'Rule: avg mark < [value]% → Amber risk flag',
              },
              {
                id: 'thresh-coursework',
                key: 'courseworkMinMark' as keyof Thresholds,
                label: 'Minimum Coursework Mark',
                description: 'Students with coursework below this value are automatically flagged Red. Maximum coursework mark is 20.',
                unit: '/20',
                min: 5, max: 18, step: 1,
                ruleText: 'Rule: coursework < [value]/20 → Red risk flag',
              },
              {
                id: 'thresh-consec-warn',
                key: 'consecutiveAbsenceWarning' as keyof Thresholds,
                label: 'Consecutive Absence Warning (sessions)',
                description: 'Number of consecutive missed lectures that triggers an Amber warning flag.',
                unit: ' sessions',
                min: 3, max: 8, step: 1,
                ruleText: 'Rule: consecutive absences ≥ [value] → Amber risk flag',
              },
              {
                id: 'thresh-consec-red',
                key: 'consecutiveAbsenceRed' as keyof Thresholds,
                label: 'Consecutive Absence Critical (sessions)',
                description: 'Number of consecutive missed lectures that triggers a Red high-risk flag.',
                unit: ' sessions',
                min: 6, max: 15, step: 1,
                ruleText: 'Rule: consecutive absences ≥ [value] → Red risk flag',
              },
              {
                id: 'thresh-attendance',
                key: 'attendanceWarningPct' as keyof Thresholds,
                label: 'Attendance Warning Threshold (%)',
                description: 'Overall attendance percentage below which a student is considered to be not attending lectures for rule evaluation purposes.',
                unit: '%',
                min: 30, max: 70, step: 5,
                ruleText: 'Rule: attendance % < [value]% → "not attending" for rule evaluation',
              },
            ].map((field) => (
              <div key={field.id} className="border-b border-border pb-6 last:border-0 last:pb-0">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <label className="block text-sm font-600 text-foreground mb-0.5">{field.label}</label>
                    <p className="text-xs text-muted-foreground leading-relaxed">{field.description}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <input
                      type="number"
                      value={thresholds[field.key]}
                      min={field.min}
                      max={field.max}
                      step={field.step}
                      onChange={(e) =>
                        setThresholds((p) => ({ ...p, [field.key]: Number(e.target.value) }))
                      }
                      className="w-20 px-3 py-2 text-sm font-700 bg-input border border-border rounded-lg text-center focus:outline-none focus:ring-2 focus:ring-ring tabular-nums"
                    />
                    <span className="text-sm text-muted-foreground whitespace-nowrap">{field.unit}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={field.min}
                    max={field.max}
                    step={field.step}
                    value={thresholds[field.key]}
                    onChange={(e) =>
                      setThresholds((p) => ({ ...p, [field.key]: Number(e.target.value) }))
                    }
                    className="flex-1 accent-primary"
                  />
                </div>
                <p className="text-xs font-500 text-primary mt-2 font-mono">
                  {field.ruleText.replace('[value]', String(thresholds[field.key]))}
                </p>
              </div>
            ))}

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleSaveThresholds}
                disabled={isSavingThresholds}
                className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-600 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-60"
              >
                {isSavingThresholds ? (
                  <>
                    <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                    </svg>
                    Saving…
                  </>
                ) : (
                  <><Save size={15} />Save Thresholds</>
                )}
              </button>
              <button
                onClick={() => { setThresholds(DEFAULT_THRESHOLDS); toast.info('Thresholds reset to system defaults.'); }}
                className="flex items-center gap-2 border border-border bg-card text-foreground px-4 py-2.5 rounded-lg text-sm font-500 hover:bg-muted transition-colors"
              >
                <RefreshCw size={14} />
                Reset to Defaults
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── AUDIT LOG TAB ── */}
      {activeTab === 'audit' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border flex items-center justify-between">
            <h2 className="text-base font-600 text-foreground">System Audit Log</h2>
            <span className="text-xs text-muted-foreground">{mockAuditLogs.length} entries</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  {['Timestamp', 'User', 'Action', 'Target', 'IP Address'].map((h) => (
                    <th key={`audit-th-${h}`} className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {mockAuditLogs.map((log) => (
                  <tr key={log.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 text-xs font-mono text-muted-foreground whitespace-nowrap">{log.timestamp}</td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-600 text-foreground whitespace-nowrap">{log.userName}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={[
                        'inline-flex px-2 py-0.5 rounded-full text-xs font-600',
                        log.action.includes('deleted') || log.action.includes('deactivated') ? 'risk-red-badge' :
                        log.action.includes('updated') || log.action.includes('imported') ? 'risk-amber-badge' :
                        'bg-secondary text-primary border border-secondary',
                      ].join(' ')}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{log.target}</td>
                    <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{log.ipAddress}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete confirm modal */}
      <ConfirmModal
        open={deleteTarget !== null}
        title="Delete Lecturer Account"
        message={`This will permanently remove ${lecturers.find((l) => l.id === deleteTarget)?.name}'s account and all associated data. This action cannot be undone.`}
        confirmLabel="Delete Account"
        cancelLabel="Keep Account"
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        variant="danger"
      />
    </div>
  );
}