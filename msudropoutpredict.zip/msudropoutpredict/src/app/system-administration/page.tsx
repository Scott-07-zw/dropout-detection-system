import AppLayout from '@/components/AppLayout';
import SystemAdminClient from './components/SystemAdminClient';

export default function SystemAdministrationPage() {
  return (
    <AppLayout userRole="admin" userName="System Administrator">
      <SystemAdminClient />
    </AppLayout>
  );
}