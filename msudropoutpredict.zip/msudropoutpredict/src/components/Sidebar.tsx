'use client';
import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  ClipboardList,
  AlertTriangle,
  Users,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  BookOpen,
} from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: number;
  roles: Array<'lecturer' | 'hod' | 'admin'>;
}

const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/', icon: <LayoutDashboard size={18} />, roles: ['lecturer', 'hod', 'admin'] },
  { label: 'Attendance', href: '/attendance-screen', icon: <ClipboardList size={18} />, roles: ['lecturer', 'admin'] },
  { label: 'Risk Overview', href: '/student-risk-overview', icon: <Users size={18} />, badge: 7, roles: ['lecturer', 'hod', 'admin'] },
  { label: 'Risk Reports', href: '/student-risk-report', icon: <AlertTriangle size={18} />, badge: 3, roles: ['lecturer', 'hod', 'admin'] },
  { label: 'Administration', href: '/system-administration', icon: <Settings size={18} />, roles: ['admin'] },
];

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
  userRole: 'lecturer' | 'hod' | 'admin';
  userName: string;
}

export default function Sidebar({ collapsed, onToggleCollapse, mobileOpen, onMobileClose, userRole, userName }: SidebarProps) {
  const pathname = usePathname();

  const visibleItems = navItems.filter((item) => item.roles.includes(userRole));

  return (
    <aside
      className={[
        'flex flex-col bg-primary text-primary-foreground flex-shrink-0 sidebar-transition z-30',
        'fixed lg:relative h-full',
        collapsed ? 'w-16' : 'w-60',
        mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
      ].join(' ')}
    >
      {/* Logo */}
      <div className={['flex items-center border-b border-white/10 flex-shrink-0 h-16', collapsed ? 'justify-center px-2' : 'px-4 gap-3'].join(' ')}>
        <div className="flex items-center gap-2 min-w-0">
          <AppLogo size={32} />
          {!collapsed && (
            <div className="min-w-0">
              <p className="text-sm font-700 text-primary-foreground leading-tight truncate">MSU DropoutPredict</p>
              <p className="text-xs text-white/60 leading-tight truncate">Risk Management</p>
            </div>
          )}
        </div>
        <button
          onClick={onMobileClose}
          className="lg:hidden ml-auto p-1 hover:bg-white/10 rounded"
          aria-label="Close sidebar"
        >
          <ChevronLeft size={16} />
        </button>
      </div>

      {/* Role badge */}
      {!collapsed && (
        <div className="px-4 py-3 border-b border-white/10">
          <span className={[
            'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-600',
            userRole === 'admin' ? 'bg-accent/20 text-accent' :
            userRole === 'hod'? 'bg-purple-400/20 text-purple-300' : 'bg-white/15 text-white/80'
          ].join(' ')}>
            <BookOpen size={11} />
            {userRole === 'hod' ? 'Head of Department' : userRole === 'admin' ? 'Administrator' : 'Lecturer'}
          </span>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {!collapsed && (
          <p className="px-2 py-1.5 text-xs font-600 uppercase tracking-widest text-white/40">Navigation</p>
        )}
        {visibleItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href));
          return (
            <Link
              key={`nav-${item.href}`}
              href={item.href}
              onClick={onMobileClose}
              title={collapsed ? item.label : undefined}
              className={[
                'flex items-center gap-3 px-2.5 py-2.5 rounded-lg text-sm font-500 transition-all duration-150 group relative',
                isActive
                  ? 'bg-white/20 text-white shadow-sm'
                  : 'text-white/70 hover:bg-white/10 hover:text-white',
              ].join(' ')}
            >
              <span className="flex-shrink-0">{item.icon}</span>
              {!collapsed && <span className="flex-1 truncate">{item.label}</span>}
              {!collapsed && item.badge && (
                <span className="flex-shrink-0 bg-risk-red text-white text-xs font-700 px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                  {item.badge}
                </span>
              )}
              {collapsed && item.badge && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-risk-red rounded-full" />
              )}
              {collapsed && (
                <span className="absolute left-full ml-2 px-2 py-1 bg-foreground text-background text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                  {item.label}
                  {item.badge ? ` (${item.badge})` : ''}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-white/10 p-2">
        {!collapsed && (
          <div className="px-2 py-2 mb-1">
            <p className="text-xs font-600 text-white/90 truncate">{userName}</p>
            <p className="text-xs text-white/50 capitalize">{userRole}</p>
          </div>
        )}
        <Link
          href="/login-screen"
          className="flex items-center gap-3 px-2.5 py-2.5 rounded-lg text-sm font-500 text-white/60 hover:bg-white/10 hover:text-white transition-all duration-150"
          title={collapsed ? 'Log Out' : undefined}
        >
          <LogOut size={18} />
          {!collapsed && <span>Log Out</span>}
        </Link>
        <button
          onClick={onToggleCollapse}
          className="hidden lg:flex items-center gap-3 w-full px-2.5 py-2.5 rounded-lg text-sm font-500 text-white/60 hover:bg-white/10 hover:text-white transition-all duration-150"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={18} /> : <><ChevronLeft size={18} /><span>Collapse</span></>}
        </button>
      </div>
    </aside>
  );
}