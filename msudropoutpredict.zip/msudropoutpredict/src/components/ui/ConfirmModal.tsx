'use client';
import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmModalProps {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  variant?: 'danger' | 'warning';
}

export default function ConfirmModal({
  open, title, message, confirmLabel = 'Confirm', cancelLabel = 'Cancel',
  onConfirm, onCancel, variant = 'danger',
}: ConfirmModalProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-foreground/40">
      <div className="bg-card rounded-xl shadow-xl w-full max-w-md fade-in border border-border">
        <div className="flex items-start gap-4 p-6">
          <div className={`p-2 rounded-lg flex-shrink-0 ${variant === 'danger' ? 'bg-red-50' : 'bg-amber-50'}`}>
            <AlertTriangle size={20} className={variant === 'danger' ? 'text-risk-red' : 'text-risk-amber'} />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-600 text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground mt-1">{message}</p>
          </div>
          <button onClick={onCancel} className="p-1 hover:bg-muted rounded transition-colors flex-shrink-0">
            <X size={16} className="text-muted-foreground" />
          </button>
        </div>
        <div className="flex items-center justify-end gap-3 px-6 pb-6">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-sm font-500 text-foreground bg-muted hover:bg-border rounded-lg transition-colors"
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            className={`px-4 py-2 text-sm font-600 text-white rounded-lg transition-all active:scale-95 ${
              variant === 'danger' ? 'bg-risk-red hover:bg-red-700' : 'bg-risk-amber hover:bg-amber-700'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}