import React from 'react';
import type { RiskLevel } from '@/lib/mockData';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
  showDot?: boolean;
}

const labels: Record<RiskLevel, string> = {
  green: 'No Risk',
  amber: 'Moderate Risk',
  red: 'High Risk',
};

const classes: Record<RiskLevel, string> = {
  green: 'risk-green-badge',
  amber: 'risk-amber-badge',
  red: 'risk-red-badge',
};

const dotClasses: Record<RiskLevel, string> = {
  green: 'bg-risk-green',
  amber: 'bg-risk-amber',
  red: 'bg-risk-red',
};

const sizeClasses = {
  sm: 'text-xs px-2 py-0.5',
  md: 'text-xs px-2.5 py-1',
  lg: 'text-sm px-3 py-1.5',
};

export default function RiskBadge({ level, size = 'md', showDot = true }: RiskBadgeProps) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-600 ${classes[level]} ${sizeClasses[size]}`}>
      {showDot && <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${dotClasses[level]}`} />}
      {labels[level]}
    </span>
  );
}