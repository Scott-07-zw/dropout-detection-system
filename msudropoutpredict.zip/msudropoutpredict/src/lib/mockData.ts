// BACKEND INTEGRATION POINT: Replace all mock data with MySQL/XAMPP API calls
// Connect to: http://localhost/msu-dropout/api/ endpoints

export type RiskLevel = 'green' | 'amber' | 'red';

export interface Student {
  id: string;
  regNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  programme: string;
  year: number;
  department: string;
  isRegistered: boolean;
  riskLevel: RiskLevel;
}

export interface Module {
  id: string;
  code: string;
  name: string;
  lecturerId: string;
  department: string;
  year: number;
  semester: number;
  enrolledCount: number;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  moduleId: string;
  sessionDate: string;
  present: boolean;
  sessionNumber: number;
}

export interface Grade {
  id: string;
  studentId: string;
  moduleId: string;
  courseworkMark: number;
  test1Mark: number;
  test2Mark: number;
  assignmentMark: number;
  examMark: number | null;
}

export interface StudentModuleRisk {
  studentId: string;
  moduleId: string;
  riskLevel: RiskLevel;
  attendancePercent: number;
  consecutiveAbsences: number;
  courseworkMark: number;
  averageMark: number;
  isRegistered: boolean;
  riskReasons: string[];
}

export interface LecturerAccount {
  id: string;
  name: string;
  email: string;
  role: 'lecturer' | 'hod' | 'admin';
  department: string;
  modulesCount: number;
  status: 'active' | 'inactive';
  lastLogin: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  target: string;
  timestamp: string;
  ipAddress: string;
}

// ─── STUDENTS ───────────────────────────────────────────────────────────────
export const mockStudents: Student[] = [
  { id: 'stu-001', regNumber: 'R213456H', firstName: 'Takudzwa', lastName: 'Moyo', email: 'takudzwa.moyo@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: true, riskLevel: 'green' },
  { id: 'stu-002', regNumber: 'R213789K', firstName: 'Simbai', lastName: 'Chikwanda', email: 'simbai.chikwanda@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: true, riskLevel: 'amber' },
  { id: 'stu-003', regNumber: 'R214012L', firstName: 'Nyasha', lastName: 'Dzingai', email: 'nyasha.dzingai@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: false, riskLevel: 'red' },
  { id: 'stu-004', regNumber: 'R213201M', firstName: 'Tatenda', lastName: 'Mhuri', email: 'tatenda.mhuri@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: true, riskLevel: 'amber' },
  { id: 'stu-005', regNumber: 'R213567N', firstName: 'Ruvimbo', lastName: 'Sithole', email: 'ruvimbo.sithole@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: true, riskLevel: 'green' },
  { id: 'stu-006', regNumber: 'R214345P', firstName: 'Kudakwashe', lastName: 'Ncube', email: 'kudakwashe.ncube@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: false, riskLevel: 'red' },
  { id: 'stu-007', regNumber: 'R213890Q', firstName: 'Farai', lastName: 'Manyika', email: 'farai.manyika@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: true, riskLevel: 'green' },
  { id: 'stu-008', regNumber: 'R214678R', firstName: 'Blessing', lastName: 'Zvobgo', email: 'blessing.zvobgo@students.msu.ac.zw', programme: 'BSc Computer Science', year: 2, department: 'Computer Science', isRegistered: true, riskLevel: 'red' },
  { id: 'stu-009', regNumber: 'R213123S', firstName: 'Chiedza', lastName: 'Mapfumo', email: 'chiedza.mapfumo@students.msu.ac.zw', programme: 'BSc Information Systems', year: 3, department: 'Computer Science', isRegistered: true, riskLevel: 'amber' },
  { id: 'stu-010', regNumber: 'R214901T', firstName: 'Tinotenda', lastName: 'Gumbo', email: 'tinotenda.gumbo@students.msu.ac.zw', programme: 'BSc Information Systems', year: 3, department: 'Computer Science', isRegistered: true, riskLevel: 'green' },
  { id: 'stu-011', regNumber: 'R213444U', firstName: 'Munyaradzi', lastName: 'Choto', email: 'munyaradzi.choto@students.msu.ac.zw', programme: 'BSc Information Systems', year: 3, department: 'Computer Science', isRegistered: false, riskLevel: 'red' },
  { id: 'stu-012', regNumber: 'R214222V', firstName: 'Shamiso', lastName: 'Banda', email: 'shamiso.banda@students.msu.ac.zw', programme: 'BSc Information Systems', year: 3, department: 'Computer Science', isRegistered: true, riskLevel: 'green' },
];

// ─── MODULES ────────────────────────────────────────────────────────────────
export const mockModules: Module[] = [
  { id: 'mod-001', code: 'CS201', name: 'Data Structures & Algorithms', lecturerId: 'lec-001', department: 'Computer Science', year: 2, semester: 1, enrolledCount: 12 },
  { id: 'mod-002', code: 'CS202', name: 'Database Systems', lecturerId: 'lec-001', department: 'Computer Science', year: 2, semester: 1, enrolledCount: 12 },
  { id: 'mod-003', code: 'IS301', name: 'Systems Analysis & Design', lecturerId: 'lec-002', department: 'Computer Science', year: 3, semester: 1, enrolledCount: 4 },
  { id: 'mod-004', code: 'CS203', name: 'Computer Networks', lecturerId: 'lec-003', department: 'Computer Science', year: 2, semester: 1, enrolledCount: 8 },
];

// ─── GRADES ─────────────────────────────────────────────────────────────────
export const mockGrades: Grade[] = [
  { id: 'grd-001', studentId: 'stu-001', moduleId: 'mod-001', courseworkMark: 18, test1Mark: 72, test2Mark: 68, assignmentMark: 75, examMark: null },
  { id: 'grd-002', studentId: 'stu-002', moduleId: 'mod-001', courseworkMark: 10, test1Mark: 28, test2Mark: 22, assignmentMark: 31, examMark: null },
  { id: 'grd-003', studentId: 'stu-003', moduleId: 'mod-001', courseworkMark: 8, test1Mark: 15, test2Mark: 18, assignmentMark: 20, examMark: null },
  { id: 'grd-004', studentId: 'stu-004', moduleId: 'mod-001', courseworkMark: 13, test1Mark: 35, test2Mark: 29, assignmentMark: 40, examMark: null },
  { id: 'grd-005', studentId: 'stu-005', moduleId: 'mod-001', courseworkMark: 19, test1Mark: 78, test2Mark: 82, assignmentMark: 80, examMark: null },
  { id: 'grd-006', studentId: 'stu-006', moduleId: 'mod-001', courseworkMark: 5, test1Mark: 12, test2Mark: 9, assignmentMark: 15, examMark: null },
  { id: 'grd-007', studentId: 'stu-007', moduleId: 'mod-001', courseworkMark: 20, test1Mark: 88, test2Mark: 91, assignmentMark: 85, examMark: null },
  { id: 'grd-008', studentId: 'stu-008', moduleId: 'mod-001', courseworkMark: 7, test1Mark: 19, test2Mark: 14, assignmentMark: 22, examMark: null },
  { id: 'grd-009', studentId: 'stu-009', moduleId: 'mod-003', courseworkMark: 14, test1Mark: 42, test2Mark: 38, assignmentMark: 45, examMark: null },
  { id: 'grd-010', studentId: 'stu-010', moduleId: 'mod-003', courseworkMark: 19, test1Mark: 74, test2Mark: 71, assignmentMark: 78, examMark: null },
  { id: 'grd-011', studentId: 'stu-011', moduleId: 'mod-003', courseworkMark: 9, test1Mark: 21, test2Mark: 18, assignmentMark: 25, examMark: null },
  { id: 'grd-012', studentId: 'stu-012', moduleId: 'mod-003', courseworkMark: 18, test1Mark: 65, test2Mark: 70, assignmentMark: 68, examMark: null },
];

// ─── ATTENDANCE RECORDS ──────────────────────────────────────────────────────
export const mockAttendance: AttendanceRecord[] = [
  // stu-001 — good attendance
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-001-${i + 1}`, studentId: 'stu-001', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i !== 5, sessionNumber: i + 1 })),
  // stu-002 — moderate, 6 consecutive absences
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-002-${i + 1}`, studentId: 'stu-002', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i < 4, sessionNumber: i + 1 })),
  // stu-003 — poor attendance, unregistered
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-003-${i + 1}`, studentId: 'stu-003', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i < 2, sessionNumber: i + 1 })),
  // stu-004 — moderate
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-004-${i + 1}`, studentId: 'stu-004', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i % 3 !== 0, sessionNumber: i + 1 })),
  // stu-005 — excellent
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-005-${i + 1}`, studentId: 'stu-005', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: true, sessionNumber: i + 1 })),
  // stu-006 — very poor, unregistered
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-006-${i + 1}`, studentId: 'stu-006', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i < 1, sessionNumber: i + 1 })),
  // stu-007 — excellent
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-007-${i + 1}`, studentId: 'stu-007', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i !== 8, sessionNumber: i + 1 })),
  // stu-008 — very poor, 11 consecutive absences
  ...Array.from({ length: 12 }, (_, i) => ({ id: `att-008-${i + 1}`, studentId: 'stu-008', moduleId: 'mod-001', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i < 1, sessionNumber: i + 1 })),
  // stu-009
  ...Array.from({ length: 10 }, (_, i) => ({ id: `att-009-${i + 1}`, studentId: 'stu-009', moduleId: 'mod-003', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i % 4 !== 0, sessionNumber: i + 1 })),
  // stu-010
  ...Array.from({ length: 10 }, (_, i) => ({ id: `att-010-${i + 1}`, studentId: 'stu-010', moduleId: 'mod-003', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: true, sessionNumber: i + 1 })),
  // stu-011
  ...Array.from({ length: 10 }, (_, i) => ({ id: `att-011-${i + 1}`, studentId: 'stu-011', moduleId: 'mod-003', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i < 2, sessionNumber: i + 1 })),
  // stu-012
  ...Array.from({ length: 10 }, (_, i) => ({ id: `att-012-${i + 1}`, studentId: 'stu-012', moduleId: 'mod-003', sessionDate: `2026-08-${String(i + 1).padStart(2, '0')}`, present: i !== 3 && i !== 4, sessionNumber: i + 1 })),
];

// ─── RISK ENGINE ─────────────────────────────────────────────────────────────
export function computeRisk(
  student: Student,
  grade: Grade | undefined,
  attendance: AttendanceRecord[]
): StudentModuleRisk {
  const reasons: string[] = [];
  const total = attendance.length;
  const attended = attendance.filter((a) => a.present).length;
  const attendancePercent = total > 0 ? Math.round((attended / total) * 100) : 0;

  // Consecutive absences from most recent session
  const sorted = [...attendance].sort((a, b) => b.sessionNumber - a.sessionNumber);
  let consecutive = 0;
  for (const rec of sorted) {
    if (!rec.present) consecutive++;
    else break;
  }

  const courseworkMark = grade?.courseworkMark ?? 0;
  const averageMark =
    grade
      ? Math.round((grade.test1Mark + grade.test2Mark + grade.assignmentMark) / 3)
      : 0;

  let riskLevel: RiskLevel = 'green';

  // Rule 1: Not registered → Red
  if (!student.isRegistered) {
    riskLevel = 'red';
    reasons.push('Student is NOT registered — automatic high risk flag.');
  }

  // Rule 2: Coursework below 12 → Red
  if (courseworkMark < 12) {
    if (riskLevel !== 'red') riskLevel = 'red';
    reasons.push(`Coursework mark is ${courseworkMark}/20 — below the minimum threshold of 12.`);
  }

  // Rule 3: 10+ consecutive absences → Red
  if (consecutive >= 10) {
    if (riskLevel !== 'red') riskLevel = 'red';
    reasons.push(`Student has missed ${consecutive} consecutive lectures — exceeds the 10-lecture threshold.`);
  }

  // Rule 4: 5–9 consecutive absences → Amber (if not already red)
  if (consecutive >= 5 && consecutive < 10) {
    if (riskLevel === 'green') riskLevel = 'amber';
    reasons.push(`Student has missed ${consecutive} consecutive lectures — exceeds the 5-lecture warning threshold.`);
  }

  // Rule 5: Academic marks below 30% + registered + not attending → Amber
  if (averageMark < 30 && student.isRegistered && attendancePercent < 50) {
    if (riskLevel === 'green') riskLevel = 'amber';
    reasons.push(`Average academic mark is ${averageMark}% (below 30%) and attendance is only ${attendancePercent}%.`);
  }

  // Rule 6: Academic marks below 30% + registered + attending → Amber
  if (averageMark < 30 && student.isRegistered && attendancePercent >= 50) {
    if (riskLevel === 'green') riskLevel = 'amber';
    reasons.push(`Average academic mark is ${averageMark}% (below 30%) despite attending ${attendancePercent}% of lectures.`);
  }

  if (reasons.length === 0) {
    reasons.push('Student meets all academic, attendance, and registration requirements. No risk detected.');
  }

  return {
    studentId: student.id,
    moduleId: grade?.moduleId ?? '',
    riskLevel,
    attendancePercent,
    consecutiveAbsences: consecutive,
    courseworkMark,
    averageMark,
    isRegistered: student.isRegistered,
    riskReasons: reasons,
  };
}

// ─── LECTURER ACCOUNTS ───────────────────────────────────────────────────────
export const mockLecturers: LecturerAccount[] = [
  { id: 'lec-001', name: 'Dr. Tendai Muzorewa', email: 'lecturer@msu.ac.zw', role: 'lecturer', department: 'Computer Science', modulesCount: 2, status: 'active', lastLogin: '30/08/2026 16:42' },
  { id: 'lec-002', name: 'Prof. Nomsa Dube', email: 'hod@msu.ac.zw', role: 'hod', department: 'Computer Science', modulesCount: 1, status: 'active', lastLogin: '30/08/2026 09:15' },
  { id: 'lec-003', name: 'Mr. Blessing Chirinda', email: 'chirinda@msu.ac.zw', role: 'lecturer', department: 'Computer Science', modulesCount: 1, status: 'active', lastLogin: '29/08/2026 14:30' },
  { id: 'lec-004', name: 'Ms. Rutendo Makoni', email: 'makoni@msu.ac.zw', role: 'lecturer', department: 'Mathematics', modulesCount: 3, status: 'active', lastLogin: '28/08/2026 11:00' },
  { id: 'lec-005', name: 'Dr. Farai Chigumba', email: 'chigumba@msu.ac.zw', role: 'lecturer', department: 'Physics', modulesCount: 2, status: 'inactive', lastLogin: '15/07/2026 08:22' },
];

// ─── AUDIT LOGS ──────────────────────────────────────────────────────────────
export const mockAuditLogs: AuditLog[] = [
  { id: 'log-001', userId: 'lec-001', userName: 'Dr. Tendai Muzorewa', action: 'Attendance marked', target: 'CS201 — Session 12', timestamp: '30/08/2026 16:42', ipAddress: '192.168.1.45' },
  { id: 'log-002', userId: 'lec-002', userName: 'Prof. Nomsa Dube', action: 'Risk report viewed', target: 'R214012L — Nyasha Dzingai', timestamp: '30/08/2026 09:18', ipAddress: '192.168.1.12' },
  { id: 'log-003', userId: 'lec-001', userName: 'Dr. Tendai Muzorewa', action: 'Grade updated', target: 'R213789K — Simbai Chikwanda — CS201', timestamp: '29/08/2026 15:10', ipAddress: '192.168.1.45' },
  { id: 'log-004', userId: 'admin', userName: 'System Administrator', action: 'Student data imported', target: '12 students — CS201 cohort', timestamp: '28/08/2026 08:00', ipAddress: '192.168.1.1' },
  { id: 'log-005', userId: 'lec-003', userName: 'Mr. Blessing Chirinda', action: 'Attendance marked', target: 'CS203 — Session 11', timestamp: '28/08/2026 13:55', ipAddress: '192.168.1.78' },
  { id: 'log-006', userId: 'admin', userName: 'System Administrator', action: 'Rule threshold updated', target: 'Consecutive absence warning: 5 → 5', timestamp: '27/08/2026 10:30', ipAddress: '192.168.1.1' },
  { id: 'log-007', userId: 'lec-002', userName: 'Prof. Nomsa Dube', action: 'Lecturer note added', target: 'R214345P — Kudakwashe Ncube', timestamp: '26/08/2026 14:00', ipAddress: '192.168.1.12' },
];

// ─── WEEKLY ATTENDANCE TREND ─────────────────────────────────────────────────
export const weeklyAttendanceTrend = [
  { week: 'Wk 1', rate: 94, absent: 6 },
  { week: 'Wk 2', rate: 91, absent: 9 },
  { week: 'Wk 3', rate: 88, absent: 12 },
  { week: 'Wk 4', rate: 85, absent: 15 },
  { week: 'Wk 5', rate: 79, absent: 21 },
  { week: 'Wk 6', rate: 76, absent: 24 },
  { week: 'Wk 7', rate: 72, absent: 28 },
  { week: 'Wk 8', rate: 68, absent: 32 },
];

export const riskDistributionData = [
  { name: 'No Risk', value: 5, fill: '#16a34a' },
  { name: 'Moderate Risk', value: 4, fill: '#d97706' },
  { name: 'High Risk', value: 3, fill: '#dc2626' },
];

export const moduleAvgMarks = [
  { module: 'CS201', avg: 48, enrolled: 8 },
  { module: 'CS202', avg: 61, enrolled: 8 },
  { module: 'IS301', avg: 55, enrolled: 4 },
  { module: 'CS203', avg: 43, enrolled: 8 },
];

export const DEMO_CREDENTIALS = [
  { role: 'Lecturer', email: 'lecturer@msu.ac.zw', password: 'MSU@Lec2026', name: 'Dr. Tendai Muzorewa' },
  { role: 'HOD', email: 'hod@msu.ac.zw', password: 'MSU@HOD2026', name: 'Prof. Nomsa Dube' },
  { role: 'Admin', email: 'admin@msu.ac.zw', password: 'MSU@Admin2026', name: 'System Administrator' },
];